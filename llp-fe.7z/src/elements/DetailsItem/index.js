export { DetailsItem } from './DetailsItem';
