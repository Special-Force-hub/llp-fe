export { DetailsCard } from './DetailsCard';
