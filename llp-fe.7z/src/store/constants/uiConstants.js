// Global UI Action
export const OPEN_MENU = 'OPEN_MENU';
export const OPEN_DETAILS = 'OPEN_DETAILS';
export const   SET_COLLAPSED = 'SET_COLLAPSED';
