const emailActionTypes = {
  GET_EMAIL: 'GET_EMAIL',
  SET_EMAIL: 'SET_EMAIL',
  DEL_EMAIL: 'DEL_EMAIL',
};

export default emailActionTypes;
