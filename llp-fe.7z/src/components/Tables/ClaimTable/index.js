export { ClaimTable } from './ClaimTable';
