export { EmailBuildingDetail } from './EmailBuildingDetail';
