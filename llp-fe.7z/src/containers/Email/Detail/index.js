export { EmailDetail } from './EmailDetail';
