export { InviteLandlordDetail } from './InviteLandlordDetail';
