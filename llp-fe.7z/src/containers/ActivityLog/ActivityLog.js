import { DashboardLayoutContainer } from 'components/Layouts/DashboardLayout';
import { Box } from '@mui/material';

export const ActivityLog = () => {
  return (
    <DashboardLayoutContainer>
      <Box></Box>
    </DashboardLayoutContainer>
  );
};
