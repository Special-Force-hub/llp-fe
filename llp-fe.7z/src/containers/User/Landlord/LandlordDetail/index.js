export { LandlordDetail } from './LandlordDetail';
