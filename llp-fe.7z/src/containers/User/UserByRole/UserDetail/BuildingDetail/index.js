export { DetailBuilding } from './BuildingDetail';
