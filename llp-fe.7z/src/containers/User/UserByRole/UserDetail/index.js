export { UserDetail } from './UserDetail';
