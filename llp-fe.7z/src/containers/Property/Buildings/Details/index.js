export { BuildingDetail } from './BuildingDetail';
