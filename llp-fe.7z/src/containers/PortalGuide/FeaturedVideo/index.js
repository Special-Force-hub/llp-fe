export { FeaturedVideo } from './FeaturedVideo';
