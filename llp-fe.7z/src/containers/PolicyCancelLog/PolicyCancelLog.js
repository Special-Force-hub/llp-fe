import { DashboardLayoutContainer } from 'components/Layouts/DashboardLayout';
import { Box } from '@mui/material';

export const PolicyCancelLog = () => {
  return (
    <DashboardLayoutContainer>
      <Box></Box>
    </DashboardLayoutContainer>
  );
};
