export { UpdatePassword } from './UpdatePassword';
