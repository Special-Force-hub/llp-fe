module.exports = {
  name: 'Leap',
  desc: 'Leap',
  prefix: 'Leap',
  footerText: 'Leap',
  logoText: 'Leap',
};
