export const data1 = [
  {
    name: 'Page A',
    uv: 4000,
    pv: 2400,
    amt: 2400,
  },
  {
    name: 'Page B',
    uv: 3000,
    pv: 1398,
    amt: 2210,
  },
  {
    name: 'Page C',
    uv: 2000,
    pv: 9800,
    amt: 2290,
  },
  {
    name: 'Page D',
    uv: 2780,
    pv: 3908,
    amt: 2000,
  },
  {
    name: 'Page E',
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
];

export const data2 = [
  {
    name: 'Approved',
    value: 400,
  },
  {
    name: 'Declined',
    value: 100,
  },
];

export const data3 = [
  {
    name: 'Last',
    value: 4321,
  },
  {
    name: 'Current',
    value: 9876,
  },
  {
    name: 'Future',
    value: 10500,
  },
];
