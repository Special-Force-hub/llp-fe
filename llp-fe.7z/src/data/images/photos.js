const images = [
  'https://res.cloudinary.com/walden-global-services/image/upload/v1544584529/dandelion/4.jpg',
];

export default images;
